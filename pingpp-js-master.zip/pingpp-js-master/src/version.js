module.exports = {
  v: '2.2.1'
};
