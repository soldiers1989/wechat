var redirectBase = require('./commons/redirect_base');

module.exports = {

  handleCharge: function(charge) {
    redirectBase.handleCharge(charge);
  }
};
